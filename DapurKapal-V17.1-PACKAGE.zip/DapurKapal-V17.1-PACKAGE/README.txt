Dapur Kapal V17.1 Web Edition

Upload/replace only index.html in the GitHub Pages repository.
This build removes the legacy notification/render hook that could create duplicate notification buttons.
It keeps existing dk161_* storage keys for compatibility.
No service worker is included.
